package org.example;

import org.example.util.JedisUtils;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisDataException;

/**
 * 1. 设定一个服务方法，用于模拟实际业务调用的服务，内部采用打印模拟调用
 * 2. 在业务调用前服务调用控制单元，内部使用redis进行控制，参照之前的方案
 * 3. 对调用超限使用异常进行控制，异常处理设定为打印提示信息
 * 4. 主程序启动3个线程，分别表示3种不同用户的
 */
public class Service{

    private String id;
    private int num;

    public Service(String id,int num){
        this.id = id;
        this.num = num;
    }

    /**
     * VIP 服务控制单元
     */
    public void vipService(){

//        Jedis jedis = new Jedis("127.0.0.1",6379);
        Jedis jedis = JedisUtils.getJedis();
        String value = jedis.get("compId:"+id);
        try {
            // 判断该值是否存在
            if (value == null){
                // 不存在,创建该值
                jedis.setex("compId:"+id,5,Long.MAX_VALUE-num+"");
            }else {
                // 存在，让值自增，调用业务
                Long val = jedis.incr("compId:"+id);
                business(id,num-(Long.MAX_VALUE-val));
            }
        }catch (JedisDataException e){
            System.out.println("用户compId:"+id+"VIP试用次数已到达上限，请升级会员级别");
        }finally {
            jedis.close();
        }
    }

    public void business(String id,Long val){
        System.out.println("用户"+"compId:"+id+"业务操作执行第："+val+"次");
    }
}

class MyThread extends Thread{
    Service service;

    public MyThread(String id,int num){
        service = new Service(id,num);
    }

    @Override
    public void run(){
        while (true){
            service.vipService();
            try {
                Thread.sleep(300L);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Main{
    public static void main(String[] args) {
        MyThread mt1 = new MyThread("初级用户",10);
        MyThread mt2 = new MyThread("高级用户",30);

        mt1.start();
        mt2.start();
    }
}