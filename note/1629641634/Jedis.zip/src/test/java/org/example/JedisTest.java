package org.example;

import org.junit.Test;
import redis.clients.jedis.Jedis;

import java.util.List;
import java.util.Map;

public class JedisTest {

    @Test
    public void jedisTest(){
        // 1. 连接 Jedis
        Jedis jedis = new Jedis("127.0.0.1",6379);
        // 2. 操纵Jedis
        jedis.set("name","itheima");
        String name = jedis.get("name");
        System.out.println(name);
        // 3. 关闭连接
        jedis.close();
    }

    @Test
    public void listTest(){
        // 1. 连接 Jedis
        Jedis jedis = new Jedis("127.0.0.1",6379);
        // 2. 操纵Jedis
        jedis.lpush("list1","a","b","c");
        jedis.lpush("list1","x");
        List<String> list1 = jedis.lrange("list1",0,-1);
        for (String list : list1) {
            System.out.println(list);
        }
        System.out.println(jedis.llen("list1"));

        // 3. 关闭连接
        jedis.close();
    }

    @Test
    public void hashTest(){
        // 1. 连接 Jedis
        Jedis jedis = new Jedis("127.0.0.1",6379);
        // 2. 操纵Jedis
        jedis.hset("hash1","a1","a1");
        jedis.hset("hash1","b1","b1");
        jedis.hset("hash1","c1","c1");

        Map<String,String> hash1 = jedis.hgetAll("hash1");
        System.out.println(hash1);
        System.out.println(jedis.hlen("hash1"));
        // 3. 关闭连接
        jedis.close();
    }
}
